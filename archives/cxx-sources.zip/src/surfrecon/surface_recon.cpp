#include "surface_recon.h"

#include <iostream>
#include <random>
#include <algorithm>

#ifdef _OPENMP
#include <omp.h>
#endif

#include <Eigen/Dense>
#include <Eigen/Sparse>

using FloatType = double;
using IndexType = int64_t;
using EigenMatrix = Eigen::MatrixXd;
using EigenVector = Eigen::VectorXd;
using SparseMatrix = Eigen::SparseMatrix<FloatType, Eigen::ColMajor, IndexType>;
using Triplet = Eigen::Triplet<FloatType, IndexType>;

#include "common/kdtree.h"
#include "common/progress.h"
#include "common/volume.h"
#include "mcubes/mcubes.h"

// Wendland's RBF
// Morse et al. 2001,
// "Interpolating Implicit Surfaces From Scattered Surface Data
//  Using Compactly Supported Radial Basis Functions"
inline double csrbf(const Vec3 &x, const Vec3 &y, double s = 0.1) {
    const double r = length(x - y) / s;
    const double a = std::max(0.0, 1.0 - r);
    const double b = 4.0 * r + 1.0;
    return (a * a * a * a) * b;
}

// Custom struct for KD tree
struct Point : public Vec3 {
    Point() {}
    Point(const Vec3 &v, int index = -1) : Vec3(v), i(index) {}
    int i;
};

void surfaceFromPoints(const std::vector<Vec3> &positions, const std::vector<Vec3> &normals,
                       std::vector<Vec3> *outVerts, std::vector<uint32_t> *outFaces,
                       double suppRadius, int mcubeDivs) {

    // In this program, point cloud is first scaled and translated to be inside [-0.5, 0.5]^3 regular cube.
    // This prevents to adjust parameters for CS-RBF or off-surface positions.

    const int nPoints = (int)positions.size();
    printf("#point: %d\n", nPoints);

    // Compute bounding box
    double minX = 1.0e20, maxX = -1.0e20;
    double minY = 1.0e20, maxY = -1.0e20;
    double minZ = 1.0e20, maxZ = -1.0e20;
    for (int i = 0; i < nPoints; i++) {
        minX = std::min(minX, positions[i].x);
        maxX = std::max(maxX, positions[i].x);
        minY = std::min(minY, positions[i].y);
        maxY = std::max(maxY, positions[i].y);
        minZ = std::min(minZ, positions[i].z);
        maxZ = std::max(maxZ, positions[i].z);
    }

    const double maxExtent = std::max(maxX - minX, std::max(maxY - minY, maxZ - minZ)) * 1.1;
    const Vec3 center = Vec3(minX + maxX, minY + maxY, minZ + maxZ) * 0.5;
    const Vec3 origin = center - Vec3(maxExtent) * 0.5;
    printf("origin: %f, %f, %f\n", origin.x, origin.y, origin.z);
    printf("center: %f, %f, %f\n", center.x, center.y, center.z);
    printf("size: %f\n", maxExtent);

    // Normalize input data and construct KD tree.
    KDTree<Point> tree;
    std::vector<Point> points;

    // Generate off-surface points
    std::vector<Vec3> xyz;
    std::vector<double> fvals;

     NOT_IMPL_ERROR();

    // Construct a sparse linear system
    const int64_t N = xyz.size();
    SparseMatrix AA(N + 4, N + 4);
    Eigen::VectorXd bb(N + 4);
    std::vector<Triplet> triplets;

     NOT_IMPL_ERROR();
    AA.setFromTriplets(triplets.begin(), triplets.end());

    // Solve sparse linear system
    printf("Solving linear system...\n");
    printf("  non-zeros: %d\n", (int)AA.nonZeros());
    printf("   mat-size: %d x %d\n", (int)AA.rows(), (int)AA.cols());

    Eigen::BiCGSTAB<SparseMatrix> solver;
    solver.setMaxIterations(500);
    solver.setTolerance(1.0e-12);
    solver.compute(AA);
    const Eigen::VectorXd weights = solver.solve(bb);

    printf("Finish!\n");
    printf("#iterations: %zu\n", solver.iterations());
    printf("#error: %f\n", solver.error());

    // Evaluate values of implicit function at lattice points
    const int div = mcubeDivs;
    Volume volume(div, div, div);

     NOT_IMPL_ERROR();

    // Marching cubes to get iso-contour
    marchCubes(volume, outVerts, outFaces, 0.5);

    // Scale and translate back to original domain
    for (auto &p : *outVerts) {
        p = (p / div) * maxExtent + origin;
    }
}